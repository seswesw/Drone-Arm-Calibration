from utils.mavlink_handler import listen_mavlink
from utils.arduino_comm import ArduinoController
import config

def main():
    arduino = ArduinoController(config.SERIAL_PORT, config.BAUDRATE)

    def on_event(event):
        print("→ Событие:", event)
        if event == "HEARTBEAT":
            arduino.send_angles([90, 90, 90, 90])
        elif event == "ARMED":
            arduino.send_angles([120, 100, 80, 60])
        elif event == "LAND":
            arduino.send_angles([90, 90, 90, 90])

    listen_mavlink(config.MAVLINK_UDP, on_event)

if __name__ == "__main__":
    main()
