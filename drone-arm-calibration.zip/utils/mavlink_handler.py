from pymavlink import mavutil

def listen_mavlink(udp_port, on_event):
    master = mavutil.mavlink_connection(udp_port)
    print("[MAVLINK] Подключение...")
    master.wait_heartbeat()
    print("[MAVLINK] Сердцебиение получено")

    while True:
        msg = master.recv_match(blocking=True)
        if not msg:
            continue

        t = msg.get_type()
        if t == "HEARTBEAT":
            if msg.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED:
                on_event("ARMED")
            else:
                on_event("HEARTBEAT")
        elif t == "COMMAND_ACK" and msg.command == mavutil.mavlink.MAV_CMD_NAV_LAND:
            on_event("LAND")
