import serial
import time

class ArduinoController:
    def __init__(self, port, baudrate):
        self.ser = serial.Serial(port, baudrate, timeout=1)
        time.sleep(2)

    def send_angles(self, angles):
        msg = ''.join(f"{angle:03}" for angle in angles) + "\n"
        print("→ Отправляю:", msg.strip())
        self.ser.write(msg.encode())
